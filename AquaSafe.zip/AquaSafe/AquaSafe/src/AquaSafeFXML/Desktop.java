package AquaSafeFXML;

public class Desktop {

    public static Object getDesktop() {
        return null;
    }

}
